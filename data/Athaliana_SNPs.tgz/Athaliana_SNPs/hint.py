
import sys

f=open("TAIR10_chr1.gff")
for line in f:
  if line.split()[2] == "gene":
    gene_name = line.rstrip().split("=")[-1]
    start_pos = line.split()[3]
    end_pos = line.split()[4]
    print(gene_name, start_pos, end_pos)
f.close()
